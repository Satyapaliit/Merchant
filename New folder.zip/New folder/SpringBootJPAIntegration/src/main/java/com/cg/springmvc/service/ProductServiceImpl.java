package com.cg.springmvc.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.bean.Product;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.productDoesNotExistsException;
import com.cg.springmvc.repo.IProductRepo;

@Service
public class ProductServiceImpl implements IProductService {
	
	@Autowired
	IProductRepo productRepo;
	@Override
	public Product addProduct(Product product) throws  DuplicateIdException{
		return productRepo.addProduct(product);
	}

	@Override
	public Product findProduct(long productId) throws InvalidIdException {
		return productRepo.findProduct(productId);
	}

	@Override
	public Product updateProduct(Product product) throws productDoesNotExistsException {
		return productRepo.updateProduct(product);
	}

	@Override
	public List<Product> getProductList() throws productDoesNotExistsException {
		return productRepo.getProductList();
	}

	@Override
	public Product removeProduct(int productId) throws InvalidIdException {
		return productRepo.removeProduct(productId);
	}

	//admin
	@Override
	public Merchant addMerchant(Merchant merchant) throws DuplicateIdException {
		
		return productRepo.addMerchant(merchant);
	}

}
