package com.cg.springmvc.service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.merchantDoesNotExistsException;

@Service
public interface IMerchantService {
	Merchant addMerchant(Merchant merchant) throws DuplicateIdException; 
	Merchant findMerchant(long id) throws InvalidIdException;
	Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException;
	List<Merchant> getMerchantList() throws merchantDoesNotExistsException;
	Merchant removeMerchant(int merchantId) throws InvalidIdException;

}
