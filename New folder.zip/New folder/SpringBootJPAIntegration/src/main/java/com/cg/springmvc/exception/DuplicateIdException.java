package com.cg.springmvc.exception;

public class DuplicateIdException extends RuntimeException
{
	private static final long serialVersionUID = 1L;
	public DuplicateIdException()
	{
	}

}
