package com.cg.springmvc.exception;

public class productDoesNotExistsException extends Exception
{
	private static final long serialVersionUID = 1L;

}
