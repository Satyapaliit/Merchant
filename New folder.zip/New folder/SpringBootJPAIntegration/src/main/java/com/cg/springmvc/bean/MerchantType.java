package com.cg.springmvc.bean;

public enum MerchantType
{
	NORMAL,THIRD_PARTY;
}
