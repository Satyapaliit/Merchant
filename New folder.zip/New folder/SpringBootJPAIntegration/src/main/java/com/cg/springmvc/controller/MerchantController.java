package com.cg.springmvc.controller;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.bean.Product;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.merchantDoesNotExistsException;
import com.cg.springmvc.exception.productDoesNotExistsException;
import com.cg.springmvc.service.IMerchantService;
import com.cg.springmvc.service.IProductService;

@RestController
public class MerchantController
{
	@Autowired
	IProductService productServices;
	IMerchantService merchantServices;
	
	@RequestMapping("/hello")
	public String sayHi()
	{
		return "Hey...";
	}
	
	
	//admin
	
	
	
	@RequestMapping(value="/addMerchant", method=RequestMethod.POST,produces="application/json", consumes="application/json")
	public Merchant addMerchant(@RequestBody Merchant merchant) throws DuplicateIdException	{
		merchant=merchantServices.addMerchant(merchant);
		
		return merchant;
		
	}
	
	
	@RequestMapping(value="/findMerchant/{id}",produces="application/json")
	public Merchant findMerchant(@PathVariable long id) throws InvalidIdException
	{
		Merchant merchant=new Merchant();
		merchant=merchantServices.findMerchant(id);
		return merchant;
	}
	
	
	

	@RequestMapping(value="/getMerchantList",produces="application/json")
	public List<Merchant> getMerchantList() throws merchantDoesNotExistsException
	{
		List<Merchant> list=merchantServices.getMerchantList();
		return list;
	}
	
	

	@RequestMapping(value="/removeMerchant/{id}",produces="application/json")
	public Merchant removeMerchant(@PathVariable int id) throws InvalidIdException
	{
		Merchant merchant=new Merchant();
		merchant=merchantServices.removeMerchant(id);
		return merchant;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	@RequestMapping(value="/addProduct", method=RequestMethod.POST,produces="application/json", consumes="application/json")
	public Product getProductDetails(@RequestBody Product customer) throws DuplicateIdException	{
		customer=productServices.addProduct(customer);
		
		return customer;
		
	}
	
	@RequestMapping(value="/findProduct/{id}",produces="application/json")
	public Product findProduct(@PathVariable long id) throws InvalidIdException
	{
		Product customer=new Product();
		customer=productServices.findProduct(id);
		return customer;
	}

	@RequestMapping(value="/getProductList",produces="application/json")
	public List<Product> getProductList() throws productDoesNotExistsException
	{
		List<Product> list=productServices.getProductList();
		return list;
	}
	
	@RequestMapping(value="/updateProductDetails", method=RequestMethod.POST,produces="application/json", consumes="application/json")
	public Product updateProductDetails(@RequestBody Product customer) throws productDoesNotExistsException
	{
		customer=productServices.updateProduct(customer);
		
		return customer;
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	

	@RequestMapping(value="/removeProduct/{id}",produces="application/json")
	public Product removeProduct(@PathVariable int id) throws InvalidIdException
	{
		Product customer=new Product();
		customer=productServices.removeProduct(id);
		return customer;
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Id Id not found")
	@ExceptionHandler({InvalidIdException.class})
	public void handleException()
	{
	}
	
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Duplicate Id")
	@ExceptionHandler({DuplicateIdException.class})
	public void handleDuplicateIdException()
	{
	}
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Product Does Not Exists!")
	@ExceptionHandler({productDoesNotExistsException.class})
	public void handleInvalidProductException()
	{
	}
	
	@ResponseStatus(value=HttpStatus.NOT_FOUND, reason="Merchant Does Not Exists!")
	@ExceptionHandler({merchantDoesNotExistsException.class})
	public void handleInvalidMerchantIdException()
	{
	}
	
	
	
	
	
}
