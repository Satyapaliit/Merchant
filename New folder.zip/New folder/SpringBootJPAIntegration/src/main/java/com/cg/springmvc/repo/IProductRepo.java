package com.cg.springmvc.repo;

import java.util.List;


import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.bean.Product;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.productDoesNotExistsException;

@Repository
public interface IProductRepo
{
	Product addProduct(Product product) throws DuplicateIdException; 
	Product findProduct(long productId) throws InvalidIdException;
	Product updateProduct(Product product) throws productDoesNotExistsException;
	List<Product> getProductList() throws productDoesNotExistsException;
	Product removeProduct(int productId) throws InvalidIdException;
	Merchant addMerchant(Merchant merchant) throws DuplicateIdException;
}
