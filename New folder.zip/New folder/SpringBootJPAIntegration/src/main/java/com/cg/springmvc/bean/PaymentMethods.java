package com.cg.springmvc.bean;

public enum PaymentMethods 
{
	CASH_ON_DELIVERY , NETBANKING , CARD;
}
