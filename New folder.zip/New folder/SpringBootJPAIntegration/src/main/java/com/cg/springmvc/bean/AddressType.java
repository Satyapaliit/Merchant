package com.cg.springmvc.bean;

public enum AddressType 
{
	HOME,WORK
}
