package com.cg.springmvc.repo;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.merchantDoesNotExistsException;


@Transactional
@Repository
public class MerchantRepoImpl implements IMerchantRepo
{
	@PersistenceContext
	private EntityManager entityManager;
	
	//getter
	public EntityManager getEntityManager()
	{
		return entityManager;
	}
	
	@Override
	public Merchant addMerchant(Merchant merchant) throws DuplicateIdException
	{
		long id=merchant.getMerchantId();
		if(entityManager.find(Merchant.class, id)!=null)
		{
			throw new DuplicateIdException();
		}
		else
		{
			entityManager.persist(merchant);
			entityManager.flush();
			return merchant;
		}
	}

	@Override
	public Merchant findMerchant(long merchantId) throws InvalidIdException
	{
		
		Merchant merchant=entityManager.find(Merchant.class, merchantId);
		if(merchant==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			return merchant;
		}
	}

	@Override
	public Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException
	{
		if(entityManager.find(Merchant.class, merchant.getMerchantId())==null)
		{
			throw new merchantDoesNotExistsException();
		}
		else
		{
			entityManager.merge(merchant);
			entityManager.flush();
			return merchant;
		}
	}

	@Override
	public List<Merchant> getMerchantList() throws merchantDoesNotExistsException {
		
		TypedQuery<Merchant> query=entityManager.createQuery("select merchant from Merchant merchant", Merchant.class);
		List<Merchant> list=query.getResultList();
		return list;
	}

	@Override
	public Merchant removeMerchant(int merchantId) throws InvalidIdException {
		Merchant merchant=entityManager.find(Merchant.class,merchantId);
		if(merchant==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			entityManager.remove(merchantId);
			return merchant;
		}
	}


}
