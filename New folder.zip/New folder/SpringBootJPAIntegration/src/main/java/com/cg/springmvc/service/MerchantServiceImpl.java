package com.cg.springmvc.service;

import java.util.List;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.merchantDoesNotExistsException;
import com.cg.springmvc.repo.IMerchantRepo;

@Service
public class MerchantServiceImpl implements IMerchantService {
	
	@Autowired
	IMerchantRepo merchantRepo;
	@Override
	public Merchant addMerchant(Merchant merchant) throws  DuplicateIdException{
		return merchantRepo.addMerchant(merchant);
	}

	@Override
	public Merchant findMerchant(long merchantId) throws InvalidIdException {
		return merchantRepo.findMerchant(merchantId);
	}

	@Override
	public Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException {
		return merchantRepo.updateMerchant(merchant);
	}

	@Override
	public List<Merchant> getMerchantList() throws merchantDoesNotExistsException {
		return merchantRepo.getMerchantList();
	}

	@Override
	public Merchant removeMerchant(int merchantId) throws InvalidIdException {
		return merchantRepo.removeMerchant(merchantId);
	}

	

}
