package com.cg.springmvc.repo;

import java.util.List;



import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.merchantDoesNotExistsException;

@Repository
public interface IMerchantRepo
{
	Merchant addMerchant(Merchant merchant) throws DuplicateIdException; 
	Merchant findMerchant(long id) throws InvalidIdException;
	Merchant updateMerchant(Merchant merchant) throws merchantDoesNotExistsException;
	List<Merchant> getMerchantList() throws merchantDoesNotExistsException;
	Merchant removeMerchant(int merchantId) throws InvalidIdException;
}
