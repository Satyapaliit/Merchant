package com.cg.springmvc.repo;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.bean.Merchant;
import com.cg.springmvc.bean.Product;
import com.cg.springmvc.exception.DuplicateIdException;
import com.cg.springmvc.exception.InvalidIdException;
import com.cg.springmvc.exception.productDoesNotExistsException;


@Transactional
@Repository
public class ProductRepoImpl implements IProductRepo
{
	@PersistenceContext
	private EntityManager entityManager;
	
	//getter
	public EntityManager getEntityManager()
	{
		return entityManager;
	}
	

	@Override
	public Product addProduct(Product product) throws DuplicateIdException
	{
		long id=product.getProdId();
		if(entityManager.find(Product.class, id)!=null)
		{
			throw new DuplicateIdException();
		}
		else
		{
			entityManager.persist(product);
			entityManager.flush();
			return product;
		}
		
	}

	@Override
	public Product findProduct(long productId) throws InvalidIdException
	{
		
		Product product=entityManager.find(Product.class, productId);
		if(product==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			return product;
		}
	}

	@Override
	public Product updateProduct(Product product) throws productDoesNotExistsException
	{
		if(entityManager.find(Product.class, product.getProdId())==null)
		{
			throw new productDoesNotExistsException();
		}
		else
		{
			entityManager.merge(product);
			entityManager.flush();
			return product;
		}
	}

	@Override
	public List<Product> getProductList() throws productDoesNotExistsException {
		
		TypedQuery<Product> query=entityManager.createQuery("select product from Product product", Product.class);
		List<Product> list=query.getResultList();
		return list;
	}

	@Override
	public Product removeProduct(int productId) throws InvalidIdException {
		Product product=entityManager.find(Product.class,productId);
		if(product==null)
		{
			throw new InvalidIdException();
		}
		else
		{
			entityManager.remove(productId);
			return product;
		}
	}

//admin
	@Override
	public Merchant addMerchant(Merchant merchant) throws DuplicateIdException
	{
		long id=merchant.getMerchantId();
		if(entityManager.find(Merchant.class, id)!=null)
		{
			throw new DuplicateIdException();
		}
		else
		{
			entityManager.persist(merchant);
			entityManager.flush();
			return merchant;
		}
	}

}
