package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.CartProduct;

@Transactional
public interface capstoreDao3  extends JpaRepository<CartProduct, Integer> {

}
