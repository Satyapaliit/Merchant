package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.Orders;

@Transactional
public interface capstoreDao10  extends JpaRepository<Orders, Long> {

}
