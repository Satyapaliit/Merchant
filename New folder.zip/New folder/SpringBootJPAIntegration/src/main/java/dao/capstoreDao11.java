package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.Product;

@Transactional
public interface capstoreDao11  extends JpaRepository<Product, Long> {

}
