package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.Cart;

@Transactional
public interface capstoreDao2  extends JpaRepository<Cart, Integer> {

}
