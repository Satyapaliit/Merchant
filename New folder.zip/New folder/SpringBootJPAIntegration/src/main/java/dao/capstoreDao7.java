package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.Image;

@Transactional
public interface capstoreDao7  extends JpaRepository<Image , Integer> {

}
