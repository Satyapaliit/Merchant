package dao;
import javax.transaction.Transactional;


import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springmvc.bean.WishList;

@Transactional
public interface capstoreDao13  extends JpaRepository<WishList, Integer> {

}
